from .omt import main
from . import file_log
